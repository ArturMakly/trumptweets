class UserSerializer < ActiveModel::Serializer
  attributes :nickname, :name, :email, :image
end
