class TweetSerializer < ActiveModel::Serializer
  attributes :tweet_id, :text, :media_url, :retweet_count
end
