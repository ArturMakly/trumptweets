class SessionsController < ApplicationController

  def create
    self.current_user = User.new user_params.merge(credential_params.to_h)
    redirect_to auth_twitter_success_url
  end

  def show
  end

  def failure
    notify_error message: 'Please authorize our app on twitter'
  end

  def destroy
    self.current_user = nil
    redirect_to root_url
  end

protected
  def auth_hash
    request.env['omniauth.auth']
  end

  def auth_params
    ActionController::Parameters.new(auth_hash)
  end

  def user_params
    auth_params.require(:info).permit(:nickname, :name, :email, :image)
  end

  def credential_params
    auth_params.require(:credentials).permit(:secret, :token)
  end
end
