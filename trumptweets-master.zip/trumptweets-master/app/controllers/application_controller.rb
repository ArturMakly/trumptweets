class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception

  helper_method :current_user

  rescue_from Exceptions::Unauthorized, with: -> (exception) { redirect_to '/auth/twitter' }

  rescue_from Exceptions::Forbidden, with: -> (exception) { head :forbidden }

protected
  def current_user
    @current_user ||= begin
      return unless session["user_current"].present?

      User.new session["user_current"]
    end
  end

  def current_user=(user)
    @current_user = session["user_current"] = user
  end

  def authenticate_user!
    raise Exceptions::Unauthorized.new("No user present") unless current_user.present?
  end

  def authenticate_admin!
    raise Exceptions::Forbidden.new("User should be admin") unless current_user.present? && current_user.admin?
  end

  def notify_error(title: 'Oh no!', message:)
    flash.discard
    flash[:problem] = { title: title, message: message }
    redirect_to root_path
  end

end
