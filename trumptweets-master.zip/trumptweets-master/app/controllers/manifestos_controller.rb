class ManifestosController < ApplicationController

  def show
  end

end
