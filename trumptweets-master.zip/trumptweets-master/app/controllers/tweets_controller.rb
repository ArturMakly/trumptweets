class TweetsController < ApplicationController

  before_action :authenticate_admin!, only: [:disable]

  before_action :find_tweet, only: [:success, :retweet, :disable]

  before_action :authenticate_user!, only: [:create, :retweet]

  rescue_from Twitter::Error::DuplicateStatus, with: -> (exception) { render json: { error: { title: 'Sorry!', message: 'You have already tweeted this' } }, status: :conflict }
  rescue_from Twitter::Error::Forbidden, with: -> (exception) { render json: { error: { title: 'Sorry!', message: exception.message } }, status: :conflict }

  def create
    @tweet = Tweet.create! tweet_params

    redirect_to success_tweet_path(@tweet)
  rescue Twitter::Error::Unauthorized => e
    raise Exceptions::Unauthorized.new(e.message)
  end

  def retweet
    @tweet.retweet! current_user

    redirect_to success_tweet_path(@tweet)
  rescue Twitter::Error::Unauthorized => e
    raise Exceptions::Unauthorized.new(e.message)
  end

  def disable
    @tweet.update_attributes!(active: false)

    redirect_to root_path
  end

  def success
  end

  def failure
    notify_error title: params[:title], message: params[:message]
  end

  def after_signin
  end

protected

  def tweet_params
    params.require(:tweet).permit(:text, :media_content, :media_id, :media_url).merge(creator: current_user)
  end

  def find_tweet
    @tweet = Tweet.find(params[:id])
  end

end
