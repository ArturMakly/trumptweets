class HomeController < ApplicationController

  def index
    @trending_tweets = Tweet.active.order(retweet_count: :desc, created_at: :desc).first(10)
  end

end
