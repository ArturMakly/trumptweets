class UsersController < ApplicationController

  before_action :authenticate_user!

  def show
    raise ArgumentError.new('Only "current" is allowed') unless params[:id] == 'current'

    render json: current_user, adapter: :json
  end

protected

  def client
    TwitterClient.for_user(current_user)
  end

end
