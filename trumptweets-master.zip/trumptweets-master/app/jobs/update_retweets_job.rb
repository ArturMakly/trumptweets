class UpdateRetweetsJob < ApplicationJob
  queue_as :default

  MAX_TWEETS_PER_REQUEST = 100

  def perform(*args)
    Tweet.active.find_in_batches batch_size: MAX_TWEETS_PER_REQUEST do |tweet_group|
      process_tweet_batch tweet_group
    end
  end

protected

  def process_tweet_batch(tweet_group)
    tweet_index = twitter_tweets_indexed_by_id(tweet_group)

    tweet_group.each do |tweet|
      twitter_tweet = tweet_index[tweet.tweet_id]
      if twitter_tweet
        tweet.update_attributes!(retweet_count: twitter_tweet.retweet_count)
      else
        tweet.update_attributes!(active: false)
      end
    end
  end

  def twitter_tweets_indexed_by_id(tweets)
    client.statuses(tweets.map(&:tweet_id)).index_by(&:id)
  end

  def client
    TwitterClient.for_application
  end

end
