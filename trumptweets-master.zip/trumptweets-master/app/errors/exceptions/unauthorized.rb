module Exceptions
  class Unauthorized < StandardError
  end

  class Forbidden < StandardError
  end
end
