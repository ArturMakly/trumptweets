require 'base64'

class TwitterClient

  BASE_64_CONTENT_TYPE = /data:image\/([^;]+);base64\,/

  def self.for_user(user)
    Twitter::REST::Client.new do |config|
      config.consumer_key        = ENV["TWITTER_API_KEY"]
      config.consumer_secret     = ENV["TWITTER_API_SECRET"]
      config.access_token        = user.token
      config.access_token_secret = user.secret
    end
  end

  def self.for_application
    Twitter::REST::Client.new do |config|
      config.consumer_key        = ENV["TWITTER_API_KEY"]
      config.consumer_secret     = ENV["TWITTER_API_SECRET"]
    end
  end

  def self.media_from_base64(text)
    content = Base64.decode64(text.gsub(BASE_64_CONTENT_TYPE, ''))
    extension = self.base64_extension(text)

    self.temp_file_for(content, extension) {|file| yield file }
  end

  def self.media_from_url(uri)
    content = open(uri) {|f| f.read }
    extension = File.extname(uri)

    self.temp_file_for(content, extension) {|file| yield file }
  end

private
  def self.temp_file_for(content, extension)
    file = Tempfile.new(['tweet-media', extension], encoding: 'UTF-8')
    file.binmode

    begin
      file.write content
      file.rewind

      yield file
    ensure
      file.close
      file.unlink
    end
  end

  def self.base64_extension(text, default_value = 'png')
    matching = BASE_64_CONTENT_TYPE.match(text)

    if matching
      ".#{matching[1]}"
    else
      ".#{default_value}"
    end
  end

end
