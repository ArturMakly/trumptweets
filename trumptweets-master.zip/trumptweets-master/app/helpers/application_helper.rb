module ApplicationHelper

  def tweet_static_text
    return unless ENV["TWEET_SITE_ENABLED"] == 'true'

    site_url = root_url
    site_url = site_url[0..-2] if site_url.ends_with? "/"

    text = "via : #{site_url}"

    text = "#{text} | #{ENV["TWEET_HASH_TAGS"]}" if ENV["TWEET_HASH_TAGS"].present?
    text
  end

end
