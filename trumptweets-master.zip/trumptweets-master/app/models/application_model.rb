class ApplicationModel
  include ActiveModel::Model
  include ActiveModel::Serialization
end
