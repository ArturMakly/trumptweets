class Tweet < ApplicationRecord

  attr_accessor :media_content, :creator, :skip_twitter

  validates :creator, presence: true, on: :create, unless: :skip_twitter

  validates :media_url, format: { with: /\A#{URI.regexp(['http', 'https'])}\z/ }, allow_blank: true

  validate :validate_text_or_media, on: :create

  before_create :tweet_it!, unless: :skip_twitter

  scope :active, -> { where active: true }

  def retweet!(user)
    result = client_for(user).retweet(self.tweet_id)
    self.update_attributes!(retweet_count: result.first.retweet_count) if result.present?
  end

private

  def validate_text_or_media
    errors.add :base, "Please enter some text or upload a media" if text.blank? && media_content.blank? && media_id.blank? && media_url.blank?
  end

  def tweet_it!
    if self.media_content.present?
      twitter_tweet = tweet_with_media_content
    elsif self.media_url.present?
      twitter_tweet = tweet_with_media_url
    else
      twitter_tweet = client_for_creator.update!(self.text, media_ids: self.media_id)
    end

    denormalize_twitter_result twitter_tweet
    true
  end

  def tweet_with_media_content
    TwitterClient.media_from_base64(self.media_content) {|media_object| client_for_creator.update_with_media(text, media_object) }
  end

  def tweet_with_media_url
    TwitterClient.media_from_url(self.media_url) {|media_object| client_for_creator.update_with_media(text, media_object) }
  end

  def client_for_creator
    TwitterClient.for_user(self.creator)
  end

  def client_for(user)
    TwitterClient.for_user(user)
  end

  def denormalize_twitter_result (twitter_tweet)
    self.tweet_id = twitter_tweet.id
    self.creator_nickname = creator.nickname

    if twitter_tweet.media.present?
      twitter_media = twitter_tweet.media.first
      self.media_id = twitter_media.id
      self.media_url = twitter_media.media_uri
    end
  end

end

# == Schema Information
#
# Table name: tweets
#
#  id               :integer          not null, primary key
#  text             :string
#  retweet_count    :integer          default("0")
#  tweet_id         :integer
#  media_id         :integer
#  media_url        :string
#  creator_nickname :string
#  created_at       :datetime         not null
#  updated_at       :datetime         not null
#  active           :boolean          default("true")
#
# Indexes
#
#  index_tweets_on_active         (active)
#  index_tweets_on_retweet_count  (retweet_count)
#  index_tweets_on_tweet_id       (tweet_id)
#
