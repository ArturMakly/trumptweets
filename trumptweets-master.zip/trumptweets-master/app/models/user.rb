class User < ApplicationModel

  attr_accessor :nickname, :name, :email, :image, :secret, :token

  def admin?
    admin_nickname? || admin_email?
  end

private
  def admin_email?
    ENV['ADMIN_EMAIL'].present? && ENV['ADMIN_EMAIL'] == self.email
  end

  def admin_nickname?
    ENV['ADMIN_NICKNAME'].present? && ENV['ADMIN_NICKNAME'] == self.nickname
  end

end
