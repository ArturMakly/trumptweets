# README

This README would normally document whatever steps are necessary to get the
application up and running.

Things you may want to cover:

* Ruby version

* System dependencies

* Configuration

* Database creation

* Database initialization

* How to run the test suite

* Services (job queues, cache servers, search engines, etc.)

* Deployment instructions

* ...

### Tweet footer avatar

#### Getting images

Run the following code in a Rails console to donwload 50 avatar (aprox). The real amount will depend on how many
of the first 250 followers don't have a default profile image

```ruby
path = "#{Rails.root}/app/assets/images/avatars/"
client = TwitterClient.for_user(current_user)
users = client.followers("realDonaldTrump").first(250).reject(&:default_profile?)
uris = users.map{|u| u.profile_image_uri_https(:mini)}
uris.each do |uri|
  filename = uri.to_s[uri.to_s.rindex("/")+1..-1]
  open("#{path}#{filename}", 'wb') do |file|
    file << open(uri).read
  end
end
```

You should convert them to jpg and add border-radius of 3px manually
