Rails.application.routes.draw do
  root 'home#index'

  get 'auth/twitter/callback', to: 'sessions#create'
  get 'auth/twitter/success', to: 'tweets#after_signin'
  get 'auth/failure', to: 'sessions#failure'

  get 'signout', to: 'sessions#destroy'

  resources :users, only: [:show] do
  end

  resources :tweets, only: [:create] do
    get :success, on: :member
    post :failure, on: :collection
    post :retweet, on: :member
    post :disable, on: :member
  end

  resource :manifesto, only: :show do
  end

end
