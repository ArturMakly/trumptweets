require 'rails_helper'

describe UpdateRetweetsJob, type: :job do
  let(:twitter_client) { double 'Twitter client' }

  let!(:tweet) { create :tweet, retweet_count: 2, tweet_id: 981 }
  let!(:other_tweet) { create :tweet, retweet_count: 2, tweet_id: 748 }

  before { allow(TwitterClient).to receive(:for_application).and_return twitter_client }

  it "should update retweet count" do
    twitter_response = [
      double(id: tweet.tweet_id, retweet_count: 1),
      double(id: other_tweet.tweet_id, retweet_count: 3)
    ]

    expect(twitter_client).to receive(:statuses).with([tweet, other_tweet].map(&:tweet_id)).and_return twitter_response

    UpdateRetweetsJob.perform_now

    expect(tweet.reload).to have_attributes(retweet_count: 1)
    expect(other_tweet.reload).to have_attributes(retweet_count: 3)
  end

  it "should mark tweet as not active when it's retrieved by the API" do
    twitter_response = [ double(id: tweet.tweet_id, retweet_count: 1) ]

    expect(twitter_client).to receive(:statuses).with([tweet, other_tweet].map(&:tweet_id)).and_return twitter_response

    UpdateRetweetsJob.perform_now

    expect(tweet.reload).to have_attributes(retweet_count: 1)
    expect(other_tweet.reload).not_to be_active
  end

  it "should ignore not active tweets" do
    twitter_response = [ double(id: tweet.tweet_id, retweet_count: 1) ]

    other_tweet.update_attributes!(active: false)

    expect(twitter_client).to receive(:statuses).with([tweet].map(&:tweet_id)).and_return twitter_response

    UpdateRetweetsJob.perform_now
  end

end
