RSpec.configure do |config|
  config.before :suite do
    DatabaseRewinder.init
    DatabaseRewinder.clean_all
  end

  config.after :each do
    DatabaseRewinder.clean
  end
end
