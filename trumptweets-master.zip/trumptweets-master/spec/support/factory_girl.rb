require "factories/factories"

RSpec.configure do |config|
  config.include FactoryGirl::Syntax::Methods
end
