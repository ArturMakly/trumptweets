FactoryGirl.define do

  factory :tweet do
    skip_twitter true

    text { Faker::Lorem.sentence(10) }
  end

end
