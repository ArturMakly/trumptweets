require 'rails_helper'

describe TwitterClient do

  describe "#media_from_base64" do
    let(:content) { "data:image/png;base64,iVBORw0" }
    let(:expected_extension) { ".png" }
    let(:expected_content) { Base64.decode64("iVBORw0") }

    it "assign png extension" do
      TwitterClient.media_from_base64(content) do |media|
        expect(File.extname(media)).to eq expected_extension
      end
    end

    it "don't write content type into file" do
      TwitterClient.media_from_base64(content) do |media|
        expect(media.read).to eq expected_content
      end
    end

    it "destroy file after block execution" do
      file = nil
      TwitterClient.media_from_base64(content) do |media|
        file = media
      end

      expect(file.path).not_to be
    end

    it "return result of precessing media" do
      result = TwitterClient.media_from_base64(content) {|media| "Some result" }

      expect(result).to eq "Some result"
    end

    it "assign gif extension" do
      TwitterClient.media_from_base64("data:image/gif;base64,iVBORw0") do |media|
        expect(File.extname(media)).to eq ".gif"
        expect(media.read).to eq expected_content
      end
    end

  end

  describe "#media_from_url" do
    let(:url) { "some url.png" }
    let(:expected_extension) { ".png" }
    let(:expected_content) { "file content" }

    before { expect(TwitterClient).to receive(:open).and_return :expected_content }

    it "assign png extension" do
      TwitterClient.media_from_url(url) do |media|
        expect(File.extname(media)).to eq expected_extension
      end
    end

    it "destroy file after block execution" do
      file = nil
      TwitterClient.media_from_url(url) do |media|
        file = media
      end

      expect(file.path).not_to be
    end

    it "return result of precessing media" do
      result = TwitterClient.media_from_url(url) {|media| "Some result" }

      expect(result).to eq "Some result"
    end

    it "assign gif extension" do
      TwitterClient.media_from_url("some url.gif") do |media|
        expect(File.extname(media)).to eq ".gif"
      end
    end

  end

end
