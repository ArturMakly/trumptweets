require 'rails_helper'

describe Tweet do

  describe "new instances" do
    let(:creator) { double nickname: "some nickname" }

    let(:tweet) { Tweet.new text: "some text", creator: creator }

    it "should not be valid without creator" do
      tweet.creator = nil

      expect(tweet).not_to be_valid
      expect(tweet).to have(1).errors_on(:creator)
    end

    it "should not be valid without text and media_content and media_id and media_url" do
      tweet.media_content = nil
      tweet.text = nil
      tweet.media_id = nil
      tweet.media_url = nil

      expect(tweet).not_to be_valid
      expect(tweet).to have(1).errors_on(:base)

      tweet.media_content = nil
      tweet.media_id = nil
      tweet.media_url = nil
      tweet.text = "aa"
      expect(tweet).to be_valid

      tweet.media_content = "aa"
      tweet.media_id = nil
      tweet.media_url = nil
      tweet.text = nil
      expect(tweet).to be_valid

      tweet.media_content = nil
      tweet.media_id = "aa"
      tweet.media_url = nil
      tweet.text = nil
      expect(tweet).to be_valid

      tweet.media_content = nil
      tweet.media_id = nil
      tweet.media_url = "http://www.google.com"
      tweet.text = nil
      expect(tweet).to be_valid
    end

    it "should not be valid with 'a://www.google.com'" do
      tweet.media_url = 'a://www.google.com'

      expect(tweet).not_to be_valid
      expect(tweet).to have(1).errors_on(:media_url)
    end

    it "should not be valid with 'some text http://www.google.com'" do
      tweet.media_url = 'some text http://www.google.com'

      expect(tweet).not_to be_valid
      expect(tweet).to have(1).errors_on(:media_url)
    end

    context "without media" do
      let(:creator) { double 'Twitter User', nickname: "some nickname" }
      let(:tweet) { Tweet.new text: "some text", creator: creator }

      let(:twitter_tweet) { double 'Twitter Tweet', id: 231, media: nil }
      let(:twitter_client) { double 'Twitter Client', update!: twitter_tweet, media: [] }

      before do
        expect(TwitterClient).to receive(:for_user).with(creator).and_return twitter_client
      end

      it "create tweet with text only" do
        tweet.save!

        expect(twitter_client).to have_received(:update!).with('some text', media_ids: nil)
      end

      it "denormalize twitter info" do
        expect { tweet.save! }.to change { Tweet.count }.by 1

        new_tweet = Tweet.last
        expect(new_tweet).to have_attributes(text: 'some text', retweet_count: 0, tweet_id: 231, media_id: nil, media_url: nil, creator_nickname: 'some nickname')
      end

    end

    context "with media" do
      let(:creator) { double 'Twitter User', nickname: "some nickname" }

      let(:media) { double 'Media object' }

      let(:twitter_media) { double 'Twitter Media', id: 76, media_uri: 'some uri' }
      let(:twitter_tweet) { double 'Twitter Tweet', id: 231, media: [ twitter_media ] }

      before { expect(TwitterClient).to receive(:for_user).with(creator).and_return twitter_client }

      context "with media_content" do
        let(:media_base64) { 'some base 64 content' }
        let(:tweet) { Tweet.new text: "some text", media_content: media_base64, creator: creator }
        let(:twitter_client) { double 'Twitter Client', update_with_media: twitter_tweet }

        before { expect(TwitterClient).to receive(:media_from_base64).with(media_base64).and_yield media }

        it "create tweet with text and media" do
          tweet.save!

          expect(twitter_client).to have_received(:update_with_media).with('some text', media)
        end

        it "denormalize twitter info" do
          expect { tweet.save! }.to change { Tweet.count }.by 1

          new_tweet = Tweet.last
          expect(new_tweet).to have_attributes(text: 'some text', retweet_count: 0, tweet_id: 231, media_id: 76, media_url: 'some uri', creator_nickname: 'some nickname')
        end

        context "with media only" do
          before { tweet.text = nil }

          it "create tweet with text and media" do
            tweet.save!

            expect(twitter_client).to have_received(:update_with_media).with(nil, media)
          end

          it "denormalize twitter info" do
            expect { tweet.save! }.to change { Tweet.count }.by 1

            new_tweet = Tweet.last
            expect(new_tweet).to have_attributes(text: nil, retweet_count: 0, tweet_id: 231, media_id: 76, media_url: 'some uri', creator_nickname: 'some nickname')
          end
        end
      end

      context "with media_url" do
        let(:media_url) { 'https://www.google.com.ar' }
        let(:tweet) { Tweet.new text: "some text", media_url: media_url, creator: creator }
        let(:twitter_client) { double 'Twitter Client', update_with_media: twitter_tweet }

        before { expect(TwitterClient).to receive(:media_from_url).with(media_url).and_yield media }

        it "create tweet with text and media" do
          tweet.save!

          expect(twitter_client).to have_received(:update_with_media).with('some text', media)
        end

        it "denormalize twitter info" do
          expect { tweet.save! }.to change { Tweet.count }.by 1

          new_tweet = Tweet.last
          expect(new_tweet).to have_attributes(text: 'some text', retweet_count: 0, tweet_id: 231, media_id: 76, media_url: 'some uri', creator_nickname: 'some nickname')
        end

        context "with media only" do
          before { tweet.text = nil }

          it "create tweet with text and media" do
            tweet.save!

            expect(twitter_client).to have_received(:update_with_media).with(nil, media)
          end

          it "denormalize twitter info" do
            expect { tweet.save! }.to change { Tweet.count }.by 1

            new_tweet = Tweet.last
            expect(new_tweet).to have_attributes(text: nil, retweet_count: 0, tweet_id: 231, media_id: 76, media_url: 'some uri', creator_nickname: 'some nickname')
          end
        end
      end

      context "with media id" do
        let(:media_id) { 187 }
        let(:tweet) { Tweet.new text: "some text", media_id: media_id, creator: creator }
        let(:twitter_client) { double 'Twitter Client', update!: twitter_tweet }

        it "create tweet with text and media" do
          tweet.save!

          expect(twitter_client).to have_received(:update!).with('some text', media_ids: media_id)
        end

        it "denormalize twitter info" do
          expect { tweet.save! }.to change { Tweet.count }.by 1

          new_tweet = Tweet.last
          expect(new_tweet).to have_attributes(text: 'some text', retweet_count: 0, tweet_id: 231, media_id: 76, media_url: 'some uri', creator_nickname: 'some nickname')
        end

      end

    end

  end

  describe "#retweet" do
    let(:tweet) { create :tweet, tweet_id: 171, retweet_count: 9 }
    let(:user) { double("Twitter user") }
    let(:twitter_tweet) { double("Twitter tweet", retweet_count: 19) }
    let(:client) { double("Twitter Client", retweet: [twitter_tweet]) }

    before { expect(TwitterClient).to receive(:for_user).with(user).and_return client }

    it "call retweet API" do
      tweet.retweet! user

      expect(client).to have_received(:retweet).with(tweet.tweet_id)
    end

    it "should increment retweet_count based on API result" do
      tweet.retweet! user

      expect(tweet).to have_attributes(retweet_count: 19)
    end

  end

end
