require 'rails_helper'

describe User do

  describe "#admin?" do
    let(:user) { User.new(email: 'some@email.com', nickname: "some nickname") }

    after do
      ENV['ADMIN_EMAIL'] = nil
      ENV['ADMIN_NICKNAME'] = nil
    end

    it "should be admin when email match ENV" do
      ENV['ADMIN_EMAIL'] = 'some@email.com'

      expect(user).to be_admin
    end

    it "should not be admin when email dont match ENV" do
      ENV['ADMIN_EMAIL'] = 'other@email.com'

      expect(user).not_to be_admin
    end

    it "should not be admin when name ENV is nil" do
      ENV['ADMIN_EMAIL'] = nil

      expect(user).not_to be_admin

      user.email = nil

      expect(user).not_to be_admin
    end

    it "should be admin when nickname match ENV" do
      ENV['ADMIN_NICKNAME'] = 'some nickname'

      expect(user).to be_admin
    end

    it "should not be admin when nickname dont match ENV" do
      ENV['ADMIN_NICKNAME'] = 'other nickname'

      expect(user).not_to be_admin
    end

    it "should not be admin when nickname ENV is nil" do
      ENV['ADMIN_NICKNAME'] = nil

      expect(user).not_to be_admin

      user.nickname = nil

      expect(user).not_to be_admin
    end

  end

end
