class CreateTweets < ActiveRecord::Migration[5.0]
  def change
    create_table :tweets do |t|
      t.string :text
      t.integer :retweet_count, default: 0
      t.integer :tweet_id, limit: 8
      t.integer :media_id, limit: 8
      t.string :media_url
      t.string :creator_nickname

      t.timestamps
    end
  end
end
