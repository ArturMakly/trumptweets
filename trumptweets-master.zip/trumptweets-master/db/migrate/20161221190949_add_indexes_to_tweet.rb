class AddIndexesToTweet < ActiveRecord::Migration[5.0]
  def change
    add_index :tweets, :tweet_id
    add_index :tweets, :retweet_count
  end
end
